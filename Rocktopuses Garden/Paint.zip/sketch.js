let brushColor;
let brushSize;
let saveButton;

function setup() {
  // Create the canvas and set the background color
  createCanvas(400, 400);
  background(220);
  
  // Add some spacing and style the labels and controls
  createElement('label', 'Brush Color')
    .style('color', '#555')
    .style('font-family', 'Arial')
    .position(10, height + 20);
  brushColor = createColorPicker('#000000');
  brushColor.position(10, height + 40);

  createElement('label', 'Brush Size')
    .style('color', '#555')
    .style('font-family', 'Arial')
    .position(160, height + 20);
  brushSize = createSlider(1, 50, 10);
  brushSize.position(130, height + 40);

  saveButton = createButton('Save Drawing')
    .style('font-family', 'Arial')
    .style('background-color', '#ddd')
    .style('border', 'none')
    .style('padding', '6px 12px')
    .style('border-radius', '4px')
    .style('cursor', 'pointer')
    .position(310, height + 35);
  saveButton.mousePressed(saveDrawing);
}

function draw() {
  // Update the brush settings
  stroke(brushColor.value());
  strokeWeight(brushSize.value());

  // Draw when mouse is pressed
  if (mouseIsPressed) {
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
}

function saveDrawing() {
  saveCanvas('myDrawing', 'png');
}
